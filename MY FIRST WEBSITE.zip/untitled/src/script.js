// ==========================
// NEXUS OS
// Premium Interactions
// ==========================

// Cursor Glow
const cursor = document.querySelector(".cursor-glow");

document.addEventListener("mousemove", (e) => {

    if(cursor){

        cursor.style.left = e.clientX + "px";
        cursor.style.top = e.clientY + "px";

    }

});

// Floating Windows

const windows = document.querySelectorAll(".window");

windows.forEach(card => {

    card.addEventListener("mousemove",(e)=>{

        const rect = card.getBoundingClientRect();

        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        const rotateX = (y - rect.height/2)/15;
        const rotateY = -(x - rect.width/2)/15;

        card.style.transform =
        `perspective(1000px)
         rotateX(${rotateX}deg)
         rotateY(${rotateY}deg)
         scale(1.03)`;

    });

    card.addEventListener("mouseleave",()=>{

        card.style.transform =
        "perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1)";

    });

});

// Navbar Blur

const nav = document.querySelector("nav");

window.addEventListener("scroll",()=>{

    if(window.scrollY > 40){

        nav.style.background = "rgba(10,10,20,.75)";
        nav.style.backdropFilter = "blur(30px)";

    }

    else{

        nav.style.background = "rgba(255,255,255,.05)";

    }

});

// Reveal Animation

const observer = new IntersectionObserver((entries)=>{

    entries.forEach(entry=>{

        if(entry.isIntersecting){

            entry.target.classList.add("show");

        }

    });

});

document.querySelectorAll("section").forEach(section=>{

    section.classList.add("hidden");

    observer.observe(section);

});

// Stats Counter

const stats = document.querySelectorAll(".stats h2");

stats.forEach(stat=>{

    const target = stat.innerText;

    const value = parseInt(target.replace(/\D/g,""));

    if(isNaN(value)) return;

    let count = 0;

    const speed = value/120;

    const interval = setInterval(()=>{

        count += speed;

        if(count >= value){

            stat.innerText = target;

            clearInterval(interval);

        }

        else{

            if(target.includes("%")){

                stat.innerText = Math.floor(count)+"%";

            }

            else if(target.includes("+")){

                stat.innerText = Math.floor(count)+"+";

            }

            else{

                stat.innerText = Math.floor(count);

            }

        }

    },15);

});

// Floating Animation

windows.forEach((card,index)=>{

    setInterval(()=>{

        card.animate([

            {
                transform:"translateY(0px)"
            },

            {
                transform:"translateY(-10px)"
            },

            {
                transform:"translateY(0px)"
            }

        ],{

            duration:3500 + index*400,

            iterations:1,

            easing:"ease-in-out"

        });

    },3500 + index*300);

});

// Smooth Button Glow

document.querySelectorAll("button").forEach(btn=>{

    btn.addEventListener("mouseenter",()=>{

        btn.style.boxShadow =
        "0 0 40px rgba(0,212,255,.6)";

    });

    btn.addEventListener("mouseleave",()=>{

        btn.style.boxShadow = "";

    });

});

console.log("%cNEXUS OS LOADED","color:#00D4FF;font-size:20px;font-weight:bold;");